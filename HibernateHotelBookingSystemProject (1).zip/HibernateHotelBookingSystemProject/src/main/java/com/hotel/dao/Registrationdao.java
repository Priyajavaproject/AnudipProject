package com.hotel.dao;

import com.hotel.entities.Registration;

public interface Registrationdao {


		void insert(Registration reobj) ;
		}   // insert
	


